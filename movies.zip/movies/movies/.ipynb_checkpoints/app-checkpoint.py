from flask import Flask, request, render_template
import pickle

# Initialize the Flask application
app = Flask(__name__)

# Load the pickled model
with open('movie_recommendation_model.pkl', 'rb') as file:
    model = pickle.load(file)

# Define the route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Define the route to get recommendations
@app.route('/recommend', methods=['POST'])
def recommend():
    movie_name = request.form['movie_name']
    recommendations = get_recommendations(movie_name)  # Function to get recommendations
    return render_template('recommendations.html', movie_name=movie_name, recommendations=recommendations)

# Function to get movie recommendations
def get_recommendations(movie_name):
    # Use your model to predict movie recommendations
    recommended_movies = model.get_recommendations(movie_name)  # Adjust based on your model implementation
    return recommended_movies

if __name__ == '__main__':
    app.run(debug=True)
